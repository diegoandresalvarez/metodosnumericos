clear
[A,MAP]=imread('abajo.gif');
A = flipud(A);
[ty,tx] = size(A);

% Coordenadas de los bordes (x1,y1) (x2,y2) 
x1 = 0;   y1 = -4;
x2 = 30;  y2 = -0.5;

figure
image([x1 x2],[y1 y2],A);
colormap(MAP);
axis xy
hold on

j = 0;
while true
    j = j+1;
    title(['Entre nombre curva ' num2str(j)]);
    nombre{j} = input(['Entre nombre curva ' num2str(j) ' = '],'s');

    i = 0;
    while true
        i = i+1;
        title(['Pulse tecla para obtener el punto ' num2str(i) ' de la curva ' nombre{j}]);
        % Termine de entrar puntos con ESC o con click derecho
        [xx,yy,boton] = ginput(1);
        if boton==3 | boton==27
            break;
        end;
        x(i,j) = xx;
        y(i,j) = yy;
        plot(xx,yy,'bx',xx,yy,'ro');
    end;
    if boton==27 % Termine de entrar curva con ESC
        break;
    end;    
end;

x = mean(x,2);
figure;
image([x1 x2],[y1 y2],A);
colormap(MAP);
axis xy
hold on;
plot(x,y);
legend(nombre,0);

title('Bye');
